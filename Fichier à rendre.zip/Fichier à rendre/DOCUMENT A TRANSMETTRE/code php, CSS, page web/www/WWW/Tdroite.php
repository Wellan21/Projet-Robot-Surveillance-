<?php require "CRobot.php";
$robot = new Crobot();
$robot->Tdroite();
?>