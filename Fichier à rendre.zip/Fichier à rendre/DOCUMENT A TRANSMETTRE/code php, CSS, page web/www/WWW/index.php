<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Inclusion de la feuille de style -->
    <link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <!-- Boutons de navigation pour avancer -->
    <div class="boutons-avancer">
        <button type="button" onclick="bouton('avancer.php?vit=')">
            <img src="image/avancer.png" alt="Avancer" width="80" height="80">
        </button>
    </div>

    <!-- Boutons de navigation pour reculer -->
    <div class="boutons-reculer">
        <button type="button" onclick="bouton('reculer.php?vit=')">
            <img src="image/reculer.png" alt="Reculer" width="80" height="80">
        </button>
    </div>

    <!-- Section de streaming vidéo -->
    <div class="video-stream">
        <!-- Décommentez la ligne ci-dessous si vous utilisez une image statique -->
        <!-- <img src="http://10.121.41.107:8000/stream.mjpg" width="650" height="350"> -->
        
        <!-- Source d'image dynamique basée sur l'adresse du serveur -->
        <img src="http://<?php echo $_SERVER["SERVER_ADDR"]; ?>:8000/stream.mjpg"> 
    </div>

    <!-- Boutons de navigation pour tourner à droite -->
    <div class="boutons-droit">
        <button type="button" onclick="bouton('Tdroite.php?vit=')">
            <img src="image/tourner_droite.png" alt="Tourner à Droite" width="80" height="80">
        </button>
    </div>

    <!-- Boutons de navigation pour tourner à gauche -->
    <div class="boutons-gauche">
        <button type="button" onclick="bouton('Tgauche.php?vit=')">
            <img src="image/tourner_gauche.png" alt="Tourner à Gauche" width="80" height="80">
        </button>
    </div>

    <!-- Bouton d'arrêt -->
    <div class="boutons-stop">
        <button type="button" onclick="bouton('stop.php?vit=')">
            <img src="image/stop.png" alt="Arrêt" width="80" height="80">
        </button>
    </div>

    <!-- Curseur de contrôle de vitesse -->
    <div class="vitesse">
        <input type="range" id="vitesse" name="vitesse" min="20" max="200" value="20" list="tickmarks">
        <datalist id="tickmarks">
            <!-- Repères de vitesse pour la plage de vitesses -->
            <option value="20"></option>
            <option value="30"></option>
            <!-- ... (continuer avec les autres valeurs de vitesse) ... -->
            <option value="200"></option>
        </datalist>
    </div>

    <!-- Script AJAX pour envoyer des commandes au serveur -->
    <script src="Ajax.js"></script>
    <script>
        function bouton(commande) {
            // Récupérer la valeur de la vitesse à partir du curseur
            var vitesse = document.getElementById("vitesse").value;

            // Requête AJAX pour envoyer la commande au serveur
            $.ajax({
                url: commande + vitesse, // La page contenant le script PHP
                type: "POST", // Type de requête
                success: function(result) {
                    // Gérer la réponse en cas de succès si nécessaire
                    // alert(result);
                }
            });
        }
    </script>
    <?php
    // Le code PHP peut être placé ici si nécessaire
    ?>
</body>
</html>
