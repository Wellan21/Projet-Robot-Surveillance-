<?php require "CRobot.php";
$robot = new Crobot();

$robot->avancer($_GET['vit']);
?>
