<?php require "CRobot.php";
$robot = new Crobot();
$robot->reculer( $_GET["vit"]);
?>
