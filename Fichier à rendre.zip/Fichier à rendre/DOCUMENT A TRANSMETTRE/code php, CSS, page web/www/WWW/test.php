<?php
require "CRobot.php"; 
$robot= new Crobot(); 

$robot->reculer(100); 


